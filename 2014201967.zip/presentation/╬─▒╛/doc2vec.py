import nltk
import os

def wordfreq(filename):
    file = open(filename, 'r')
    document = file.read().lower().split("\n")
    file.close()
    text = ""
    for line in document:
      text += line

    text = text.decode("utf8")
    sens = nltk.sent_tokenize(text)
    word = []
    for sen in sens:
      word.extend(nltk.word_tokenize(sen))

    stop = nltk.corpus.stopwords.words("english")
    word = [w for w in word if w.isalpha() and w not in stop]

    fdict = nltk.FreqDist(word)
    fdict = sorted(fdict.iteritems(), key=lambda d: d[1], reverse=True)
    vec = []
    if len(fdict) >= 300:
        for i in range(300):
            vec.append(fdict[i][1])
    else:
        for i in range(len(fdict)):
            vec.append(fdict[i][1])
        for i in range(len(fdict),300):
            vec.append(0)
    return vec

route = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\neg_papers"
file = open(r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\false.txt","a")
filelist = os.listdir(route)
for filename in filelist:
    if filename.endswith("txt"):
        temp = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\neg_papers\\"+filename
        vector = wordfreq(temp)
        print vector
        for i in vector:
            file.write(str(i)+" ")
        file.write("\n")
file.close()

route2 = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\True_Paper"
file = open(r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\true.txt","a")
filelist = os.listdir(route2)
for filename in filelist:
    if filename.endswith("txt"):
        temp = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\True_Paper\\"+filename
        vector = wordfreq(temp)
        print vector
        for i in vector:
            file.write(str(i)+" ")
        file.write("\n")
file.close()

route2 = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\true_test"
file = open(r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\true_test.txt","a")
filelist = os.listdir(route2)
for filename in filelist:
    if filename.endswith("txt"):
        temp = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\NLP\true_test\\"+filename
        vector = wordfreq(temp)
        print vector
        for i in vector:
            file.write(str(i)+" ")
        file.write("\n")
file.close()