import os

os.chdir("D:/Program Files/pdfminer/tools")
saveroute = "D:/True_Paper/"
pdfroute = "D:/ijcai/"

dir1 = os.listdir(pdfroute)
i = 0
for d1 in dir1:
    pdfroute2 = pdfroute+d1
    if os.path.isdir(pdfroute2):
        pdfroute3 = pdfroute2+"/PDF/"
        filenames = os.listdir(pdfroute3)
        for file in filenames:
         if file.endswith(".pdf"):
             route = pdfroute3+file
             command = "python pdf2txt.py -o "+saveroute+str(i)+".txt "+route
             i = i+1
             print i
             os.system(command)