import os

# botlist = os.listdir(r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\data\train")
#
# for bot in botlist:
#     path = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\data\train"+"\\"+bot
#     piclist = os.listdir(path)
#     length = len(piclist)
#     if length>6000:
#         x = length-6000
#         for i in range(x):
#             os.remove(path+"\\"+piclist[i])


import shutil

botlist = os.listdir(r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\data\train")
for bot in botlist:
    path = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\data\train" + "\\" + bot
    piclist = os.listdir(path)
    x = len(piclist)-5000
    for i in range(x):
        src = path+"\\"+piclist[i]
        dst = r"D:\Documents\2016-2017 autumn semester\Artificial intelligence\data\test"+"\\"+bot
        shutil.move(src,dst)