import requests

saveroute = r"D:/Documents/2016-2017 autumn semester/Artificial intelligence/文本/假论文/"
url = "http://pdos.csail.mit.edu/cgi-bin/sciredirect.cgi"

for i in range(5000):
    file = open(saveroute+str(i)+".html",'w')
    r = requests.get(url)
    file.write(r.text)
    print("完成"+str(i)+"篇论文")
