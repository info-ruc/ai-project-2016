import nltk

def doc2words(filename):
    file = open(filename, 'r')
    document = file.read().lower().split("\n")
    file.close()
    text = ""
    for line in document:
      text += line

    text = text.decode("utf8")
    sens = nltk.sent_tokenize(text)
    word = []
    for sen in sens:
      word.extend(nltk.word_tokenize(sen))

    stop = nltk.corpus.stopwords.words("english")
    word = [w for w in word if w.isalpha() and w not in stop]
    sentence = " ".join(word)
    return sentence


def addcorpus(route):
    import os
    filelist = os.listdir(route)
    corpus = []
    i = 0
    for f in filelist:
        if f.endswith(".txt"):
            corpus.append(doc2words(route+f))
        i += 1
        print i

    return corpus


def corpus2vec(route):
    from sklearn.feature_extraction.text import TfidfTransformer
    from sklearn.feature_extraction.text import CountVectorizer

    corpus = addcorpus(route)
    vectorizer = CountVectorizer()
    transformer = TfidfTransformer()
    tfidf = transformer.fit_transform(vectorizer.fit_transform(corpus))
    weight = tfidf.toarray()
    return weight

route = "D:/Documents/2016-2017_autumn_semester/Artificial_intelligence/NLP/True_Paper1/"