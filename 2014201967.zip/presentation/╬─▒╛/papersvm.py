import os
os.chdir(r"D:\Download\libsvm-3.21\python")
from svmutil import *
true = open("D:/Documents/2016-2017 autumn semester/Artificial intelligence/NLP/true.txt")
false = open("D:/Documents/2016-2017 autumn semester/Artificial intelligence/NLP/false.txt")

inputs = []
answers = []
lines = true.readlines()
for line in lines:
    inputs.append(map(int, line.split()))
    answers.append(1)

lines = false.readlines()
for line in lines:
    inputs.append(map(int, line.split()))
    answers.append(-1)



answers = [1,-1,1]
inputs = [[10,5,8],[3,2,1],[6,5,5]]
prob = svm_problem(answers,inputs)
param = svm_parameter()
m = svm_train(prob, param)
svm_save_model("paper.model",m)


true_test = open("D:/Documents/2016-2017 autumn semester/Artificial intelligence/NLP/true_test.txt")
false_test = open("D:/Documents/2016-2017 autumn semester/Artificial intelligence/NLP/false_test.txt")
inputs_test = []

answers_test = []
lines = true_test.readlines()
for line in lines:
    inputs_test.append(map(int, line.split()))
    answers_test.append(1)
    print len(answers_test)

lines = false_test.readlines()
for line in lines:
    inputs_test.append(map(int, line.split()))
    answers_test.append(-1)
    print len(answers_test)

p_labels, p_acc, p_vals = svm_predict(answers_test, inputs_test, m)