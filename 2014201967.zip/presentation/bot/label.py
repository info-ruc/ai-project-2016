# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os

train = open("/home/wangjie/caffe/data/BoT/val.txt","a")

dirlist = os.listdir(r"/home/wangjie/caffe/data/BoT/val/")
count = 0
for d in dirlist:
    filepath = "/home/wangjie/caffe/data/BoT/val/"+d+"/"
    filelist = os.listdir(filepath)
    for f in filelist:
        train.write("val/"+d+"/"+f+" "+str(count)+"\n")
    count = count+1

train.close()
